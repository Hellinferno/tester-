# Developer Guide

## 1. Getting Started

### 1.1 Prerequisites

| Tool | Version | Purpose |
|------|---------|---------|
| Node.js | >= 20.0 | Gateway, Web apps |
| Python | >= 3.11 | ML services |
| PNPM | >= 9.0 | Package management |
| Docker | >= 24.0 | Containerization |
| Docker Compose | >= 2.20 | Local infrastructure |
| Git | >= 2.40 | Version control |
| Make | >= 3.80 | Build automation |
| kubectl | >= 1.28 | Kubernetes CLI |
| Terraform | >= 1.7 | Infrastructure |
| OpenRouter API Key | Active | AI model access |

### 1.2 Repository Setup

```bash
# 1. Clone the repository
git clone git@github.com:org/slm-router.git
cd slm-router

# 2. Install dependencies
pnpm install

# 3. Set up environment files
cp infra/docker/.env.example .env
# Edit .env with your API keys

# 4. Start local infrastructure
make docker-up
# or: docker-compose -f infra/docker/docker-compose.yml up -d

# 5. Run database migrations
make migrate

# 6. Seed test data
make seed

# 7. Start all services in development mode
make dev
```

### 1.3 Environment Variables

```bash
# Core
NODE_ENV=development
API_KEY=your-api-key
JWT_SECRET=your-jwt-secret

# Database
DATABASE_URL=postgresql://user:pass@localhost:5432/slm_router_dev
REDIS_URL=redis://localhost:6379/0

# Storage
MINIO_ENDPOINT=localhost:9000
MINIO_ACCESS_KEY=minioadmin
MINIO_SECRET_KEY=minioadmin
MINIO_BUCKET=slm-router-dev

# External APIs
OPENROUTER_API_KEY=sk-or-v1-xxxxxxxx
OPENROUTER_BASE_URL=https://openrouter.ai/api/v1
DEEPGRAM_API_KEY=dg-xxxxxxxx
GOOGLE_SEARCH_API_KEY=AIzaSyxxxxxxxx
GOOGLE_SEARCH_CX=xxxxxxxx
GOOGLE_MAPS_API_KEY=AIzaSyxxxxxxxx

# ML Models
# Analysis model configured via OpenRouter API
# No local port needed - all via OpenRouter
CPU_MEMORY_UTILIZATION=0.85

# Monitoring
PROMETHEUS_PORT=9090
GRAFANA_PORT=3001
LOKI_PORT=3100
```

## 2. Development Workflow

### 2.1 Branch Strategy

```
main (production)
 └── develop (integration)
 ├── feature/ocr-enhancement
 ├── feature/stt-whisper-v3
 ├── feature/analysis-dashboard
 └── bugfix/routing-accuracy
```

- **main**: Production-ready code, protected branch
- **develop**: Integration branch, auto-deploys to staging
- **feature/**: New features, branch from develop
- **bugfix/**: Bug fixes, branch from develop
- **hotfix/**: Critical fixes, branch from main

### 2.2 Commit Convention

```
<type>(<scope>): <subject>

<body>

<footer>
```

Types: `feat`, `fix`, `docs`, `style`, `refactor`, `test`, `chore`, `perf`

Examples:
```
feat(ocr): add PaddleOCR engine support

Implement PaddleOCR as third OCR engine option.
Adds Chinese language support and table extraction.

Closes #123
```

```
fix(router): correct fallback chain ordering

Ensure fallback models are ordered by capability score,
not just alphabetically.

Fixes #456
```

### 2.3 Pull Request Process

1. Create feature branch from `develop`
2. Make changes, commit with conventional commits
3. Push branch and create PR to `develop`
4. Ensure CI passes (lint, test, build)
5. Request review from 2 team members
6. Address review comments
7. Merge via squash commit

### 2.4 Code Review Checklist

- [ ] Code follows style guidelines
- [ ] Tests added/updated
- [ ] Documentation updated
- [ ] No security vulnerabilities
- [ ] Performance considerations addressed
- [ ] Error handling implemented
- [ ] Logging added appropriately

## 3. Service Development

### 3.1 Python Services

```bash
# Navigate to service
cd services/analysis-engine

# Create virtual environment
python -m venv venv
source venv/bin/activate # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
pip install -e ../../packages/shared-python

# Run tests
pytest --cov=src --cov-report=html

# Run service locally
python -m src.main

# Format code
black src/
isort src/

# Lint code
flake8 src/
mypy src/
```

### 3.2 Node.js Services

```bash
# Navigate to service
cd services/gateway

# Install dependencies
pnpm install

# Run tests
pnpm test

# Run service locally
pnpm dev

# Format code
pnpm format

# Lint code
pnpm lint
```

### 3.3 Web Application

```bash
cd apps/web

# Install dependencies
pnpm install

# Run development server
pnpm dev

# Run tests
pnpm test
pnpm test:e2e

# Build for production
pnpm build
```

## 4. Testing

### 4.1 Test Pyramid

```
 /\
 / \\ E2E Tests (Playwright)
 / \
 / Int \\ Integration Tests
 /──────────\
 Unit Tests (Jest, Pytest)
```

### 4.2 Running Tests

```bash
# All tests
make test

# Specific service
make test-service SERVICE=ocr-service

# With coverage
make test-coverage

# E2E tests
make test-e2e

# OCR tests
make test-ocr

# STT tests
make test-stt
```

### 4.3 Writing Tests

**Python Unit Test:**
```python
# services/ocr-service/tests/test_engines.py
import pytest
from src.engines.tesseract_engine import TesseractEngine

class TestTesseractEngine:
 @pytest.fixture
 def engine(self):
 return TesseractEngine(lang='eng')

 def test_extract_clean_text(self, engine, sample_image):
 result = engine.extract(sample_image)
 assert result['text'] == "Hello World"
 assert result['confidence'] > 0.95

 def test_extract_noisy_text(self, engine, noisy_image):
 result = engine.extract(noisy_image)
 assert result['confidence'] > 0.80
```

**JavaScript Unit Test:**
```typescript
// apps/web/components/QueryBuilder.test.tsx
import { render, screen } from '@testing-library/react'
import { QueryBuilder } from './QueryBuilder'

describe('QueryBuilder', () => {
 it('renders all input modalities', () => {
 render(<QueryBuilder />)
 expect(screen.getByText('Text')).toBeInTheDocument()
 expect(screen.getByText('Image')).toBeInTheDocument()
 expect(screen.getByText('Voice')).toBeInTheDocument()
 })
})
```

## 5. Debugging

### 5.1 Local Debugging

**Python Service (VS Code):**
```json
// .vscode/launch.json
{
 "version": "0.2.0",
 "configurations": [
 {
 "name": "Analysis Engine",
 "type": "python",
 "request": "launch",
 "module": "src.main",
 "cwd": "${workspaceFolder}/services/analysis-engine",
 "env": {
 "PYTHONPATH": "${workspaceFolder}/packages/shared-python/src"
 }
 }
 ]
}
```

**Node.js Service (VS Code):**
```json
{
 "name": "Gateway",
 "type": "node",
 "request": "launch",
 "runtimeExecutable": "pnpm",
 "runtimeArgs": ["dev"],
 "cwd": "${workspaceFolder}/services/gateway"
}
```

### 5.2 Remote Debugging (Production)

```bash
# Port forward to service
kubectl port-forward svc/analysis-engine 8000:8000 -n slm-router

# Access logs
kubectl logs -f deployment/analysis-engine -n slm-router

# Exec into container
kubectl exec -it deployment/analysis-engine -n slm-router -- /bin/sh
```

### 5.3 Tracing

All requests include `trace_id` and `span_id` headers:
```
X-Trace-ID: abc123def456
X-Span-ID: span789
```

View traces in Jaeger/Tempo at `http://localhost:16686`

## 6. Database Operations

### 6.1 Migrations

```bash
# Create migration
make migrate-create NAME="add_user_preferences"

# Run migrations
make migrate-up

# Rollback one migration
make migrate-down

# Check status
make migrate-status
```

### 6.2 Seeding

```bash
# Seed development data
make seed

# Seed test data
make seed-test

# Reset database
make db-reset
```

## 7. Common Tasks

### 7.1 Add a New Model to Router

1. Update `model_configs` table:
```sql
INSERT INTO model_configs (
 model_id, provider, display_name, capabilities,
 max_tokens, context_window, cost_per_1k_input, cost_per_1k_output
) VALUES (
 'new-model/id', 'openrouter', 'New Model',
 ARRAY['vision', 'code', 'reasoning'],
 8192, 128000, 0.003, 0.015
);
```

2. Update routing rules in `services/router-service/src/strategies/`

3. Add tests in `services/router-service/tests/`

4. Update documentation

### 7.2 Add a New OCR Engine

1. Create engine class in `services/ocr-service/src/engines/`
2. Implement `extract()` method returning standard format
3. Add to engine registry in `services/ocr-service/src/main.py`
4. Add tests and fixtures
5. Update configuration schema

### 7.3 Add a New System Instruction Feature

1. Update `SystemInstructionConfig` model
2. Add UI toggle in `apps/web/components/SystemInstructionEditor/`
3. Update prompt builder to include new feature
4. Add database migration for new column
5. Update API contract

## 8. Troubleshooting

### 8.1 Common Issues

**Issue**: OCR service returns low confidence
**Solution**: Check image preprocessing settings, try different engine

**Issue**: SLM analysis timeout
**Solution**: Check CPU availability, reduce `max_model_len`, enable quantization

**Issue**: OpenRouter rate limit
**Solution**: Check key rotation, implement exponential backoff, upgrade plan

**Issue**: WebSocket connection drops
**Solution**: Check nginx timeout settings, implement heartbeat

### 8.2 Useful Commands

```bash
# Check service health
curl http://localhost:3000/health

# View service logs
make logs SERVICE=gateway

# Restart service
make restart SERVICE=analysis-engine

# Rebuild service
make rebuild SERVICE=ocr-service

# Clean everything
make clean
make docker-down
make docker-up
```

## 9. Contributing

### 9.1 Before You Start
- Read the [Rules](rules.md)
- Check existing issues and PRs
- Discuss major changes in issues first

### 9.2 Contribution Flow
1. Fork repository (external contributors)
2. Create feature branch
3. Make changes with tests
4. Update documentation
5. Submit PR with description
6. Respond to review feedback

### 9.3 Release Process
1. Update version in `package.json`
2. Update `CHANGELOG.md`
3. Create release branch
4. Run full test suite
5. Tag release: `git tag -a v1.2.0 -m "Release v1.2.0"`
6. Push tag: `git push origin v1.2.0`
7. CI builds and deploys automatically

---
*Version: 1.0 | Date: 2026-07-12*
